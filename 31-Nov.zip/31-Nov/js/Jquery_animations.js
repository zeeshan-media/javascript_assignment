$(document).ready(function(){

    // Question No 23

    $(".23 #dimension").click(function(){
            $(".23 #block").animate({
            width: "500px",
            height: "500px",
        }, 3000);
    });

    $(".23 #reset").click(function(){

        $(".23 #block").animate({
            width: "200px",
            height: "200px",
        }, 3000);

    });

    $(".23 #stop").click(function(){
        $(".23 #block").stop();
    });





    // Question No 24

    $(".24 #fade-in").click(function(){
        $(".24 #box1").fadeIn("slow");
        $(".24 #box2").fadeIn(5000);
        $(".24 #box3").fadeIn(7000);

        $(".24 #box1").fadeTo("slow",0.2);
        $(".24 #box2").fadeTo("slow",0.4);
        $(".24 #box3").fadeTo("slow",0.6);
    });
  
    $(".24 #fade-out").click(function(){
        $(".24 #box1").fadeOut("slow");
        $(".24 #box2").fadeOut(5000);
        $(".24 #box3").fadeOut(7000);

        $(".24 #box1").fadeTo("slow",0.2);
        $(".24 #box2").fadeTo("slow",0.4);
        $(".24 #box3").fadeTo("slow",0.6);
    });

    $(".24 #toggle-out").click(function(){
        $(".24 #box1").fadeToggle("slow");
        $(".24 #box2").fadeToggle(5000);
        $(".24 #box3").fadeToggle(7000);

        $(".24 #box1").fadeTo("slow",0.2);
        $(".24 #box2").fadeTo("slow",0.4);
        $(".24 #box3").fadeTo("slow",0.6);
    });




    // Question No 25

    $(".25 #slide-up").click(function(){
        $(".25 #form").slideUp(2000,function(){
            alert("Slide Up")});
    });

    $(".25 #slide-down").click(function(){
        $(".25 #form").slideDown(2000,function(){
            alert("Slide Down")});
    });

    $(".25 #slide-toggle").click(function(){
        $(".25 #form").slideToggle(2000,function(){
            alert("Slide Toggle")});
            
    });

    document.getElementById('form').addEventListener("submit",function(event){
        event.preventDefault();
    });
    $(".25 #formbutton").click(function(){
        // Id validation
        let email = $(".25 #email").val();
        let len=email.length;
    try {
        if(email=="")
        {
            $(".25 #emailwrong").html("Id Cannot be Empty");
        }
        if((email!="") && ((email.includes('@')==false) || (email[0]=='@') || (email[len-1]=='@')))
        {
            $(".25 #emailwrong").html("Invalid id(must contain @ and should have some characters before and after @)");
        }
    } catch (error) {
        $(".25 #emailwrong").html("Email is "+ error);
    }


// Feedback Validiation
    let feedback = $(".25 #textarea").val();
    try {
        if(feedback=="")
        {
            $(".25 #textareawrong").html("Feedback Cannot be Empty");
        }
    } catch (error) {
        $(".25 #textareawrong").html("Feedback is is "+ error);
    }
 
    if(email!="" && feedback!="" && ((email.includes('@')==true) && ((email[0]!='@') && (email[len-1]!='@'))))
    {

        $(".25 #form").slideUp(2000);
        $("#feedbackform").show();
    }  
    });

    $("#feedbackform").click(function()
    {
        $(".25 #form").slideDown(2000);
        $("#feedbackform").hide();
    }
    );


    // Question No 26

    $(".26 #set-css").click(function()
    {
        $(".26 #div1").css({"background-color": "blue", "color": "white"});
    });

    $(".26 #add-class").click(function()
    {
        $(".26 #div2").addClass('classAdd');
    });

    $(".26 #remove-class").click(function()
    {
        $(".26 #div2").removeClass('classAdd');
    });

    $(".26 #toggle-class").click(function()
    {
        $(".26 #div2").toggleClass('classAdd');
    });

    $(".26 #div4 #check input").change(function()
    {
        
        if(this.checked)
        {
            // let copy = $(".26 #div4 p").html();
            $(".26 #div4 #copy").click(function(){
                $(".26 #div3").addClass("div4");
            });
        }
    });


    //Question No 27

    $( function() {
        $( "#tabs" ).tabs();
    } );

    $( "#button-1" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 1);
      } );

      $( "#tabs-2 #back" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 0);
      } );

      $( "#tabs-2 #next" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 2);
      } );
       // Date picker
      $( function() {
        $( "#datepicker" ).datepicker();
      } );

      $( "#tabs-3 #back" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 1);
       
      } );

      $( "#tabs-3 #next" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 3);
      } );


      $( "#tabs-4 #back" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 2);
       
      } );

      $( "#tabs-4 #next" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 4);
      } );


      $( "#tabs-5 #back" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 3);
       
      } );

      $( "#tabs-5 #next" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 5);
      } );


      $( "#sortable" ).sortable({
        connectWith: ".connectedSortable",
        start: function(e, ui){
            $(this).attr('tempIndex',ui.item.index());
        },
        update: function(e,ui){
            let newIndex = ui.item.index();
            // let oldIndex = $(this).attr("tempIndex");
            let id = ui.item.html();
            alert('New Index of '+id+' is '+newIndex);
        }
      });


      $( "#tabs-6 #back" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs").tabs("option", "active", 2);
       
      } );

      $( "#tabs-6 #next" ).on( "click", function(event) {
        event.preventDefault();
        $("#tabs-visibility").slideUp(1000);
      } );



      // Question No 28
      $( ".28 button" ).on( "click", function() {

    // Validation-Start
            if($(".28 #from-date").val()=="")
            {
                $(".28 #fdate").html("Plz enter a valid Date");
            }
            if($(".28 #to-date").val()=="")
            {
                $(".28 #tdate").html("Plz enter a valid Date");
            }
     // Valdiation-end


            let fdate = $(".28 #from-date").val();
            let milliFdate =Date.parse(fdate)
            fromDate = new Date(fdate);
            
            let tdate = $(".28 #to-date").val();
            let milliTodate = Date.parse(tdate);
            toDate = new Date(tdate);

            days = Math.abs((milliFdate - milliTodate)/(1000*60*60*24));
            
            $(".28 #result").html("Total Number of Days Between dates From Date: "+fromDate+" To Date: "+ toDate+" is: "+ days);
      } );

});