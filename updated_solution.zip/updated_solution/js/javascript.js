
// Question_No_5
function toggle() {
    let x = document.getElementById('toggle');
    if (x.style.display === 'none') {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}


// Question_N0_7
function add(){
         let value = parseInt(document.getElementById('a').value);
         if(isNaN(value)===false)
         {
          value=value+1;
          document.getElementById('a').value=value;  
         }
         else{
            alert("Plz Enter any enteger value");
         } 
    }

function sub(){
        let value = parseInt(document.getElementById('a').value);
        if(isNaN(value)===false)
        {
         value=value-1;
         document.getElementById('a').value=value;  
        }
        else{
           alert("Plz Enter any enteger value");
        } 
   }


//    this is function used for question_6
function gotosection()
{
    let goto=document.getElementById('form');
    goto.scrollIntoView();
}


// Question_N0_8

function nameformat()
{
    let x = document.getElementById('fname').value;
    let y = document.getElementById('lname').value;
    let z = document.getElementById('nameformat');
    if(z.value==="LF")
    {
        document.getElementById('printname').innerHTML=(y+" "+x);
    }
    else
    {
        document.getElementById('printname').innerHTML=(x+" "+y);
    }
}


function textcount()
{
    let x=document.getElementById('textarea').value;
    console.log(x);
    let y=x.length;
    console.log(y);
    document.getElementById('count-text').innerHTML=y;
}


// question_ No_11
function taxcalculator()
{
    let s = parseInt(document.getElementById('salary').value);
        salary= s*12;// multiplied with 12 to get the annual salary for comaprison
        let cutoff;
        if( salary<=600000)
        {
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+(s*0);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+(s);
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(12*s*0);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(12*s-12*s*0);      
        } 

        if( salary>600000 && salary<=1200000)
        {
            cutoff=salary-600000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+(cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-((cutoff/12)*0.025));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.025);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.025));      
        } 

        if( salary>1200000 && salary<=2400000)
        {
            cutoff=salary-1200000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.125)+(15000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.125+15000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.125+15000));    
        } 

        if( salary>2400000 && salary<=3600000)
        {
            cutoff=salary-2400000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.2)+(165000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.2+165000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.2+165000)); 
        }

        if( salary>3600000 && salary<=6000000)
        {
            cutoff=salary-3600000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.25)+(405000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.25+405000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.25+405000));
        }

        if( salary>6000000 && salary<=12000000)
        {
            cutoff=salary-6000000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.325)+(1005000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.325+1005000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.325+1005000));
        }

        if( salary>12000000)
        {
            cutoff=salary-12000000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.35)+(2955000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.35+2955000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.35+2955000));
        }
}


//  Question No 12
function login()
{
    document.getElementById('form').addEventListener("submit",function(event){
        event.preventDefault();
    });
    let user = document.getElementById('username').value;
    console.log(user);
    let password = document.getElementById('password').value;
    
    if(user==='zeeshan4423' && password==='12345678')
    {
        console.log("hello");
        window.location.href = "Authorized.html"
    }
    else{
      
        if(user=="zeeshan4423" && password !="2345678")
        {
            document.getElementById('wrong').innerHTML="Incorrect Password! Enter Again"
        }

        if(user!="zeeshan4423" && password !="2345678")
        {
            document.getElementById('wrong').innerHTML="Incorrect username and Password! Enter Again"
        }
    }

}

/// Question_10
function validate(){
    document.getElementById('form1').addEventListener("submit",function(event){
        event.preventDefault();
    });

    // for name validation
    let name = document.getElementById('name').value;
    try {
        if(name.length>50)
        {
            document.getElementById('wrongname').innerHTML="Character Limit Exceeds";
        }
        if(name=="")
        {
            document.getElementById('wrongname').innerHTML="Name Cannot be Empty";
        }
    } catch (error) {
        document.getElementById('wrongname').innerHTML="Name is "+ error;
    }


    // for email validation;

    let email= document.getElementById('email').value;
    try {
        if(email=="")
        {
            document.getElementById('wrongemail').innerHTML="Email Cannot be Empty";
        }
        if(email.includes('@')==false)
        {
            document.getElementById('wrongemail').innerHTML="Invalid Email";
        }
    } catch (error) {
        document.getElementById('wrongemail').innerHTML="Email is "+ error;
    }

    let dob = document.getElementById('dob').value;
    ageMS = Date.parse(Date()) - Date.parse(dob);
    age = new Date();
    age.setTime(ageMS);
    ageYear = age.getFullYear() - 1970;

    console.log(ageYear);

}