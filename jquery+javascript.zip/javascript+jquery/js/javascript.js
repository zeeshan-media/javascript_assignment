
// Question_No_5
function toggle() {
    let x = document.getElementById('toggle');
    if (x.style.display === 'none') {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}


// Question_N0_7
function add(){
         let value = parseInt(document.getElementById('a').value);
         if(isNaN(value)===false)
         {
          value=value+1;
          document.getElementById('a').value=value;  
         }
         else{
            alert("Plz Enter any enteger value");
         } 
    }

function sub(){
        let value = parseInt(document.getElementById('a').value);
        if(isNaN(value)===false)
        {
         value=value-1;
         document.getElementById('a').value=value;  
        }
        else{
           alert("Plz Enter any enteger value");
        } 
   }


//this is function used for question_6
function gotosection()
{
    let goto=document.getElementById('form');
    goto.scrollIntoView();
}


// Question_N0_8

function nameformat()
{
    let x = document.getElementById('fname').value;
    let y = document.getElementById('lname').value;
    let z = document.getElementById('nameformat');
    if(z.value==="LF")
    {
        document.getElementById('printname').innerHTML=(y+" "+x);
    }
    else
    {
        document.getElementById('printname').innerHTML=(x+" "+y);
    }
}


function textcount()
{
    let x=document.getElementById('textarea').value;
    console.log(x);
    let y=x.length;
    console.log(y);
    document.getElementById('count-text').innerHTML=y;
}


// question_ No_11
function taxcalculator()
{
    let s = parseInt(document.getElementById('salary').value);
        salary= s*12;// multiplied with 12 to get the annual salary for comaprison
        let cutoff;
        if( salary<=600000)
        {
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+(s*0);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+(s);
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(12*s*0);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(12*s-12*s*0);      
        } 

        if( salary>600000 && salary<=1200000)
        {
            cutoff=salary-600000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+(cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-((cutoff/12)*0.025));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.025);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.025));      
        } 

        if( salary>1200000 && salary<=2400000)
        {
            cutoff=salary-1200000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.125)+(15000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.125+15000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.125+15000));    
        } 

        if( salary>2400000 && salary<=3600000)
        {
            cutoff=salary-2400000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.2)+(165000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.2+165000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.2+165000)); 
        }

        if( salary>3600000 && salary<=6000000)
        {
            cutoff=salary-3600000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.25)+(405000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.25+405000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.25+405000));
        }

        if( salary>6000000 && salary<=12000000)
        {
            cutoff=salary-6000000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.325)+(1005000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.325+1005000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.325+1005000));
        }

        if( salary>12000000)
        {
            cutoff=salary-12000000;
            document.getElementById('monthly-salary-tax').innerHTML="Monthly Taxable Amount: Rs "+ (cutoff/12);
            document.getElementById('monthly-tax-salary').innerHTML="Monthly Salary after Tax: Rs "+ (s-(((cutoff/12)*0.35)+(2955000/12)));
            document.getElementById('yearly-tax').innerHTML="Yearly Tax: Rs "+(cutoff*0.35+2955000);
            document.getElementById('yealry-salary-tax').innerHTML="Yearly Income After Tax: Rs "+(salary-(cutoff*0.35+2955000));
        }
}


//  Question No 12
function login()
{
    document.getElementById('form').addEventListener("submit",function(event){
        event.preventDefault();
    });
    let user = document.getElementById('username').value;
    console.log(user);
    let password = document.getElementById('password').value;
    
    if(user==='zeeshan4423' && password==='12345678')
    {
        console.log("hello");
        window.location.href = "Authorized.html"
    }
    else{
      
        if(user=="zeeshan4423" && password !="2345678")
        {
            document.getElementById('wrong').innerHTML="Incorrect Password! Enter Again"
        }

        if(user!="zeeshan4423" && password !="2345678")
        {
            document.getElementById('wrong').innerHTML="Username and password doesnot match ! Enter Again"
        }
    }

}

/// Question_10
function validate(){
    document.getElementById('form1').addEventListener("submit",function(event){
        event.preventDefault();
    });

    // for name validation
    let name = document.getElementById('name').value;
        name.innerHTML=""; // so that we don't have to refresh everytime we enter new value
        document.getElementById('wrongname').innerHTML="";// so that we don't have to refresh everytime we enter wrong value
    try {
        if(name.length>50)
        {
            document.getElementById('wrongname').innerHTML="Character Limit Exceeds";
        }
        if(name=="")
        {
            document.getElementById('wrongname').innerHTML="Name Cannot be Empty";
            
        }
    } catch (error) {
        document.getElementById('wrongname').innerHTML="Name is "+ error;
    }


    // for email validation;

    let email= document.getElementById('email').value;
        email.innerHTML="";// so that we don't have to refresh everytime we enter new value
        document.getElementById('wrongemail').innerHTML="";// so that we don't have to refresh everytime we enter wrong value
        let len=email.length;
    try {
        if(email=="")
        {
            document.getElementById('wrongemail').innerHTML="Email Cannot be Empty";
        }
        if((email!="") && ((email.includes('@')==false) | (email[0]=='@') || (email[len-1]=='@')))
        {
            document.getElementById('wrongemail').innerHTML="Invalid Email";
        }
    } catch (error) {
        document.getElementById('wrongemail').innerHTML="Email is "+ error;
    }
 // for date-of-birth validation
    let dob = document.getElementById('dob').value;
     dob.innerHTML=="";// so that we don't have to refresh everytime we enter new value
     document.getElementById('wrongdob').innerHTML="";// so that we don't have to refresh everytime we enter wrong value
    if(dob=="")
        {
            document.getElementById('wrongdob').innerHTML="DOB Cannot be Empty";
        }



   // for calaculation of age help from internet was taken, specifically from stack over flow but i have understood it well so explained it throughly as explained below
    milliAge = Date.parse(Date()) - Date.parse(dob); // Date.parse(Date()) gives milliseconds that have passed from jan 1,1970
                                                    // Date.parse(dob) gives milliseconds that have passed from the date_of_birth from jan,1 1970
    age = new Date();    // creating an object of date(), Date() stores the current date.
    age.setTime(milliAge); // the difference of milliseconds that we have stored in miiliAge,this will add those milliseconds to jan 1, 1970(jan 1, 1970 is the start of time, i.e, 0 milliseconds)

    Age = age.getFullYear() - 1970; // getFullYear() gives the year value in a date e.g., 2,jan 1988 (the output will be 1988 using getFullYear)
                                         // Subtracting that from 1970 will give the age of the person in years
    try {
         if(Age<13)
        {
            document.getElementById('wrongdob').innerHTML="Hello Kid you are too young for This";
        }

    
        } catch (error) {
            document.getElementById('wrongdob').innerHTML="Email is "+ error;
        }
  

     // for DropDown Menu Selection
     let selection = document.getElementById('interest');
         document.getElementById('emptyselection').innerHTML="";// so that we don't have to refresh everytime we enter wrong value

     try {
        if(selection.value==false)
        {
            document.getElementById('emptyselection').innerHTML="Please Select the value to proceed";
        }
     } catch (error) {
        document.getElementById('emptyselection').innerHTML="select is "+ error;
     }

}
