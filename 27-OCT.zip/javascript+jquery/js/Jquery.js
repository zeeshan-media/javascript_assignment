// Jquery Question

$(document).ready(function(){


    // Question_No_13
    $("#mainDiv p").css('background-color','yellow');


       // Question_NO_14
    $("#append").click(function(){
    $("#addtext p").append(" <strong>This is Appended Text</strong> ")
    });

    $("#before").click(function(){
        $("#addtext p").before(" <strong>This is Before Text</strong> ")
    });

    $("#after").click(function(){
        $("#addtext p").after(" <strong>This is After Text</strong> ")
    });

    
    $("#prepend").click(function(){
        $("#addtext p").prepend(" <strong>This is Prepend Text</strong> ")
    });


});






