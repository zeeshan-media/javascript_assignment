// Jquery Question

$(document).ready(function(){


    // Question_No_13
    $("#mainDiv p").css('background-color','yellow');



       // Question_NO_14
    $("#append").click(function(){
    $("#addtext p").append(" <strong>This is Appended Text</strong> ")
    });

    $("#before").click(function(){
        $("#addtext p").before(" <strong>This is Before Text</strong> ")
    });

    $("#after").click(function(){
        $("#addtext p").after(" <strong>This is After Text</strong> ")
    });

    
    $("#prepend").click(function(){
        $("#addtext p").prepend(" <strong>This is Prepend Text</strong> ");
    });



    // Question No-15
    $("#removebtn").click(function(){
        $("#remove p").remove();
    });



    
    // Question No-16
    $("#replacebtn").click(function(){
        $("#replace p").replaceWith("<b>" +$("#replace p").html() +"</br>");
    });

    // Question-No-17
    $("#wrapbtn").click(function(){
        $("#wrap p").wrap("<em></em>");
    });
  
    // Question N0-18
    $("#click").click(function(){
            $("#menu2").val($("#menu1").val());
    });




    // Question_19

    $("#hidetable").click(function(){
        $("#table").hide();
    });
    
    $("#showtable").click(function(){
        $("#table").show();
    });

    $("#hidetable").tooltip;
    $("#showtable").tooltip;

    
    // Question No 20
    $("#delete").click(function(){
        $(".checkbox input:checked").parent().remove();
      });
});






