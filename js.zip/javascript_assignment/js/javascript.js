function toggle() {
    let x = document.getElementById('toggle');
    if (x.style.display === 'none') {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

    function add(){
         let value = parseInt(document.getElementById('a').value);
         if(isNaN(value)===false)
         {
          value=value+1;
          document.getElementById('a').value=value;  
         }
         else{
            alert("Plz Enter any enteger value");
         } 
    }

    function sub(){
        let value = parseInt(document.getElementById('a').value);
        if(isNaN(value)===false)
        {
         value=value-1;
         document.getElementById('a').value=value;  
        }
        else{
           alert("Plz Enter any enteger value");
        } 
   }


//    this is function used for question_6
function gotosection(){
    let goto=document.getElementById('form');
    goto.scrollIntoView();
}


// function nameformat()
// {
//     let x = document.getElementById('fname').name;
//     let y = document.getElementById('lname').name;
//     let z=document.getElementById('nameformat').name;
//     if(z[0]==='FL')
//     {
//         <p>x+y</p>
//     }   

// }